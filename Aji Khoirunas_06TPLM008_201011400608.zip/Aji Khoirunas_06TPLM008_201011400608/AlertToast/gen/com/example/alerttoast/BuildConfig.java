/** Automatically generated file. DO NOT MODIFY */
package com.example.alerttoast;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}